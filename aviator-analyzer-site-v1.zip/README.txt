# Aviator Analyzer — pacote para publicação

Arquivos:
- index.html — site principal
- manifest.webmanifest — configuração para instalação como PWA
- sw.js — cache/offline básico

Para publicar, envie estes três arquivos para uma hospedagem web que forneça HTTPS.
Depois abra o endereço do site no Chrome Android.

Nota: o site faz análise estatística dos resultados introduzidos pelo utilizador e não garante nem prevê o próximo resultado do Aviator.
